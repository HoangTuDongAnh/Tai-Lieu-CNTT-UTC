public class BaiTap1_KhongChuTrinh {
    public static void main(String[] args) {
        TrangThaiDoThi A = new TrangThaiDoThi("A");
        TrangThaiDoThi B = new TrangThaiDoThi("B");
        TrangThaiDoThi C = new TrangThaiDoThi("C");
        TrangThaiDoThi D = new TrangThaiDoThi("D");
        TrangThaiDoThi E = new TrangThaiDoThi("E");
        TrangThaiDoThi F = new TrangThaiDoThi("F");
        TrangThaiDoThi G = new TrangThaiDoThi("G");
        TrangThaiDoThi H = new TrangThaiDoThi("H");
        TrangThaiDoThi I = new TrangThaiDoThi("I");
        TrangThaiDoThi K = new TrangThaiDoThi("K");

        DoThi doThi = new DoThi();

        doThi.themCung(A, B);
        doThi.themCung(A, C);
        doThi.themCung(A, D);

        doThi.themCung(B, E);
        doThi.themCung(B, F);

        doThi.themCung(C, G);
        doThi.themCung(D, H);

        doThi.themCung(E, I);
        doThi.themCung(I, K);

        System.out.println("=== TIM KIEM RONG BFS ===");
        TimKiemRong bfs = new TimKiemRong(doThi);
        TrangThaiDoThi ketQuaBFS = bfs.timKiem(A, K);
        bfs.inKetQua(ketQuaBFS);

        doThi.reset();

        System.out.println("\n=== TIM KIEM SAU DFS ===");
        TimKiemSau dfs = new TimKiemSau(doThi);
        TrangThaiDoThi ketQuaDFS = dfs.timKiem(A, K);
        dfs.inKetQua(ketQuaDFS);
    }
}