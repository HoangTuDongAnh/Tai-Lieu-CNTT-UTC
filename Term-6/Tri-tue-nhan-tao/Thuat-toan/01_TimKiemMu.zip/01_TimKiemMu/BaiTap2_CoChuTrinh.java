public class BaiTap2_CoChuTrinh {
    public static void main(String[] args) {
        TrangThaiDoThi A = new TrangThaiDoThi("A");
        TrangThaiDoThi B = new TrangThaiDoThi("B");
        TrangThaiDoThi C = new TrangThaiDoThi("C");
        TrangThaiDoThi D = new TrangThaiDoThi("D");
        TrangThaiDoThi E = new TrangThaiDoThi("E");
        TrangThaiDoThi F = new TrangThaiDoThi("F");
        TrangThaiDoThi G = new TrangThaiDoThi("G");

        DoThi doThi = new DoThi();

        doThi.themCung(A, B);
        doThi.themCung(A, C);

        doThi.themCung(B, D);
        doThi.themCung(D, G);

        doThi.themCung(C, F);
        doThi.themCung(F, E);
        doThi.themCung(E, C); // Chu trình: C -> F -> E -> C

        int gioiHanDoSau = 3;

        System.out.println("=== TIM KIEM SAU HAN CHE ===");
        System.out.println("Gioi han do sau d = " + gioiHanDoSau);

        TimKiemSauHanChe tkshc = new TimKiemSauHanChe(doThi);
        TrangThaiDoThi ketQua = tkshc.timKiem(A, G, gioiHanDoSau);
        tkshc.inKetQua(ketQua);
    }
}