public class BaiTap3_BangTrieuPhuKeCuop {
    public static void main(String[] args) {
        System.out.println("BAI TAP 3");
        System.out.println("Xay dung bang mo ta qua trinh tim kiem loi giai");
        System.out.println("Bai toan: Trieu phu va ke cuop");
        System.out.println("Trang thai: (a,b,k)");
        System.out.println("a: so trieu phu o bo trai");
        System.out.println("b: so ke cuop o bo trai");
        System.out.println("k = 1: thuyen o bo trai");
        System.out.println("k = 0: thuyen o bo phai");
        System.out.println("Trang thai dau: (3,3,1)");
        System.out.println("Trang thai ket thuc: (0,0,0)");

        TrangThaiTimKiem batDauBFS = new TrangThaiTrieuPhuKeCuopBang(3, 3, 1);
        TrangThaiTimKiem ketQuaBFS = BangMoTaTimKiem.timKiemRong(batDauBFS);
        BangMoTaTimKiem.inDuongDi(ketQuaBFS);

        TrangThaiTimKiem batDauDFS = new TrangThaiTrieuPhuKeCuopBang(3, 3, 1);
        TrangThaiTimKiem ketQuaDFS = BangMoTaTimKiem.timKiemSau(batDauDFS);
        BangMoTaTimKiem.inDuongDi(ketQuaDFS);
    }
}