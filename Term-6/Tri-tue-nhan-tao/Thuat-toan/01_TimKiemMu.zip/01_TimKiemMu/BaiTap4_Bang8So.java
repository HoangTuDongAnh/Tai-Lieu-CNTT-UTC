public class BaiTap4_Bang8So {
    public static void main(String[] args) {
        System.out.println("BAI TAP 4");
        System.out.println("Xay dung bang mo ta qua trinh tim kiem loi giai");
        System.out.println("Bai toan: 8 so");
        System.out.println("Ky hieu _: o trong");

        System.out.println("\nTrang thai dau:");
        inBanCo("2831647_5");

        System.out.println("\nTrang thai ket thuc:");
        inBanCo("1238_4765");

        TrangThaiTimKiem batDauBFS = new TrangThai8SoBang("2831647_5");
        TrangThaiTimKiem ketQuaBFS = BangMoTaTimKiem.timKiemRong(batDauBFS);
        BangMoTaTimKiem.inDuongDi(ketQuaBFS);

        TrangThaiTimKiem batDauDFS = new TrangThai8SoBang("2831647_5");
        TrangThaiTimKiem ketQuaDFS = BangMoTaTimKiem.timKiemSau(batDauDFS);
        BangMoTaTimKiem.inDuongDi(ketQuaDFS);
    }

    private static void inBanCo(String s) {
        System.out.println(s.charAt(0) + " " + s.charAt(1) + " " + s.charAt(2));
        System.out.println(s.charAt(3) + " " + s.charAt(4) + " " + s.charAt(5));
        System.out.println(s.charAt(6) + " " + s.charAt(7) + " " + s.charAt(8));
    }
}