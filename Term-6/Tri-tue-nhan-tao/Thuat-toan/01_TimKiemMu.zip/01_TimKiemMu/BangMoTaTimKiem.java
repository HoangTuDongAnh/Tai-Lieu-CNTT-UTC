import java.util.*;

public class BangMoTaTimKiem {

    public static TrangThaiTimKiem timKiemRong(TrangThaiTimKiem trangThaiDau) {
        Queue<TrangThaiTimKiem> L = new LinkedList<>();
        Set<String> Q = new LinkedHashSet<>();

        L.add(trangThaiDau);
        Q.add(trangThaiDau.maTrangThai());

        System.out.println("\n==============================");
        System.out.println("BANG MO TA TIM KIEM RONG BFS");
        System.out.println("==============================");
        System.out.printf("%-5s %-20s %-45s %-45s%n",
                "Buoc", "Phat trien u", "Trang thai ke v", "Danh sach L - Hang doi");

        int buoc = 0;
        System.out.printf("%-5d %-20s %-45s %-45s%n",
                buoc++, "", "", danhSachLToString(L));

        while (!L.isEmpty()) {
            TrangThaiTimKiem u = L.poll();

            if (u.laTrangThaiDich()) {
                System.out.printf("%-5d %-20s %-45s %-45s%n",
                        buoc++, u.maTrangThai(), "Trang thai ket thuc", "DUNG");
                return u;
            }

            List<TrangThaiTimKiem> dsKe = u.sinhTrangThaiKe();

            for (TrangThaiTimKiem v : dsKe) {
                if (!Q.contains(v.maTrangThai())) {
                    v.setCha(u);
                    L.add(v);
                    Q.add(v.maTrangThai());
                }
            }

            System.out.printf("%-5d %-20s %-45s %-45s%n",
                    buoc++,
                    u.maTrangThai(),
                    danhSachTrangThaiToString(dsKe),
                    danhSachLToString(L));
        }

        return null;
    }

    public static TrangThaiTimKiem timKiemSau(TrangThaiTimKiem trangThaiDau) {
        Deque<TrangThaiTimKiem> L = new ArrayDeque<>();
        Set<String> Q = new LinkedHashSet<>();

        L.push(trangThaiDau);
        Q.add(trangThaiDau.maTrangThai());

        System.out.println("\n==============================");
        System.out.println("BANG MO TA TIM KIEM SAU DFS");
        System.out.println("==============================");
        System.out.printf("%-5s %-20s %-45s %-45s%n",
                "Buoc", "Phat trien u", "Trang thai ke v", "Danh sach L - Ngan xep");

        int buoc = 0;
        System.out.printf("%-5d %-20s %-45s %-45s%n",
                buoc++, "", "", danhSachLToString(L));

        while (!L.isEmpty()) {
            TrangThaiTimKiem u = L.pop();

            if (u.laTrangThaiDich()) {
                System.out.printf("%-5d %-20s %-45s %-45s%n",
                        buoc++, u.maTrangThai(), "Trang thai ket thuc", "DUNG");
                return u;
            }

            List<TrangThaiTimKiem> dsKe = u.sinhTrangThaiKe();

            /*
             * DFS dùng ngăn xếp.
             * Để trạng thái kề đầu tiên được phát triển trước,
             * ta đưa các trạng thái vào stack theo thứ tự ngược.
             */
            for (int i = dsKe.size() - 1; i >= 0; i--) {
                TrangThaiTimKiem v = dsKe.get(i);

                if (!Q.contains(v.maTrangThai())) {
                    v.setCha(u);
                    L.push(v);
                    Q.add(v.maTrangThai());
                }
            }

            System.out.printf("%-5d %-20s %-45s %-45s%n",
                    buoc++,
                    u.maTrangThai(),
                    danhSachTrangThaiToString(dsKe),
                    danhSachLToString(L));
        }

        return null;
    }

    public static void inDuongDi(TrangThaiTimKiem ketQua) {
        if (ketQua == null) {
            System.out.println("\nKhong tim thay loi giai!");
            return;
        }

        Stack<TrangThaiTimKiem> duongDi = new Stack<>();
        TrangThaiTimKiem hienTai = ketQua;

        while (hienTai != null) {
            duongDi.push(hienTai);
            hienTai = hienTai.getCha();
        }

        System.out.println("\nDuong di loi giai:");
        int buoc = 0;

        while (!duongDi.isEmpty()) {
            TrangThaiTimKiem t = duongDi.pop();
            System.out.println("Buoc " + buoc + ": " + t.maTrangThai());
            buoc++;
        }

        System.out.println("Tong so buoc di: " + (buoc - 1));
    }

    private static String danhSachTrangThaiToString(Collection<TrangThaiTimKiem> ds) {
        if (ds == null || ds.isEmpty()) {
            return "";
        }

        StringBuilder sb = new StringBuilder();

        for (TrangThaiTimKiem t : ds) {
            sb.append(t.maTrangThai()).append(" ");
        }

        return sb.toString().trim();
    }

    private static String danhSachLToString(Collection<TrangThaiTimKiem> ds) {
        if (ds == null || ds.isEmpty()) {
            return "";
        }

        StringBuilder sb = new StringBuilder();

        for (TrangThaiTimKiem t : ds) {
            sb.append(t.maTrangThai()).append(" ");
        }

        return sb.toString().trim();
    }
}