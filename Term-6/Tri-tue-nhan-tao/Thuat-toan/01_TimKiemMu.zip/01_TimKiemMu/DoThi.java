import java.util.*;

public class DoThi {
    private Map<TrangThaiDoThi, List<TrangThaiDoThi>> danhSachKe;

    public DoThi() {
        danhSachKe = new LinkedHashMap<>();
    }

    public void themTrangThai(TrangThaiDoThi u) {
        danhSachKe.putIfAbsent(u, new ArrayList<>());
    }

    public void themCung(TrangThaiDoThi u, TrangThaiDoThi v) {
        themTrangThai(u);
        themTrangThai(v);
        danhSachKe.get(u).add(v);
    }

    public List<TrangThaiDoThi> layKe(TrangThaiDoThi u) {
        return danhSachKe.getOrDefault(u, new ArrayList<>());
    }

    public void reset() {
        for (TrangThaiDoThi u : danhSachKe.keySet()) {
            u.father = null;
            u.doSau = 0;
        }
    }
}