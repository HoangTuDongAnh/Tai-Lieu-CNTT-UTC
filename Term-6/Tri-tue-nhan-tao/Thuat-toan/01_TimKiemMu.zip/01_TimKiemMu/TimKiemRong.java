import java.util.*;

public class TimKiemRong {
    private DoThi doThi;

    public TimKiemRong(DoThi doThi) {
        this.doThi = doThi;
    }

    public TrangThaiDoThi timKiem(TrangThaiDoThi batDau, TrangThaiDoThi ketThuc) {
        Queue<TrangThaiDoThi> L = new LinkedList<>();
        List<TrangThaiDoThi> Q = new ArrayList<>();

        L.add(batDau);
        Q.add(batDau);

        while (!L.isEmpty()) {
            TrangThaiDoThi u = L.poll();

            if (u.equals(ketThuc)) {
                return u;
            }

            for (TrangThaiDoThi v : doThi.layKe(u)) {
                if (!Q.contains(v)) {
                    v.father = u;
                    L.add(v);
                    Q.add(v);
                }
            }
        }

        return null;
    }

    public void inKetQua(TrangThaiDoThi ketQua) {
        if (ketQua == null) {
            System.out.println("Khong tim thay duong di!");
            return;
        }

        Stack<TrangThaiDoThi> duongDi = new Stack<>();
        TrangThaiDoThi hienTai = ketQua;

        while (hienTai != null) {
            duongDi.push(hienTai);
            hienTai = hienTai.father;
        }

        System.out.println("Duong di tim duoc:");
        while (!duongDi.isEmpty()) {
            System.out.print(duongDi.pop());
            if (!duongDi.isEmpty()) {
                System.out.print(" -> ");
            }
        }
        System.out.println();
    }
}