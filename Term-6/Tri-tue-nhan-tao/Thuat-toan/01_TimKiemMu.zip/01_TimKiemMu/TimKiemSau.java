import java.util.*;

public class TimKiemSau {
    private DoThi doThi;

    public TimKiemSau(DoThi doThi) {
        this.doThi = doThi;
    }

    public TrangThaiDoThi timKiem(TrangThaiDoThi batDau, TrangThaiDoThi ketThuc) {
        Stack<TrangThaiDoThi> L = new Stack<>();
        List<TrangThaiDoThi> Q = new ArrayList<>();

        L.push(batDau);
        Q.add(batDau);

        while (!L.isEmpty()) {
            TrangThaiDoThi u = L.pop();

            if (u.equals(ketThuc)) {
                return u;
            }

            List<TrangThaiDoThi> dsKe = new ArrayList<>(doThi.layKe(u));

            // Đảo để khi push vào stack, thứ tự duyệt gần giống thứ tự đã khai báo
            Collections.reverse(dsKe);

            for (TrangThaiDoThi v : dsKe) {
                if (!Q.contains(v)) {
                    v.father = u;
                    L.push(v);
                    Q.add(v);
                }
            }
        }

        return null;
    }

    public void inKetQua(TrangThaiDoThi ketQua) {
        if (ketQua == null) {
            System.out.println("Khong tim thay duong di!");
            return;
        }

        Stack<TrangThaiDoThi> duongDi = new Stack<>();
        TrangThaiDoThi hienTai = ketQua;

        while (hienTai != null) {
            duongDi.push(hienTai);
            hienTai = hienTai.father;
        }

        System.out.println("Duong di tim duoc:");
        while (!duongDi.isEmpty()) {
            System.out.print(duongDi.pop());
            if (!duongDi.isEmpty()) {
                System.out.print(" -> ");
            }
        }
        System.out.println();
    }
}