import java.util.*;

public class TimKiemSauHanChe {
    private DoThi doThi;

    public TimKiemSauHanChe(DoThi doThi) {
        this.doThi = doThi;
    }

    public TrangThaiDoThi timKiem(TrangThaiDoThi batDau, TrangThaiDoThi ketThuc, int gioiHanDoSau) {
        Stack<TrangThaiDoThi> L = new Stack<>();
        List<TrangThaiDoThi> Q = new ArrayList<>();

        batDau.doSau = 0;
        L.push(batDau);
        Q.add(batDau);

        while (!L.isEmpty()) {
            TrangThaiDoThi u = L.pop();

            if (u.equals(ketThuc)) {
                return u;
            }

            List<TrangThaiDoThi> dsKe = new ArrayList<>(doThi.layKe(u));
            Collections.reverse(dsKe);

            for (TrangThaiDoThi v : dsKe) {
                int doSauMoi = u.doSau + 1;

                if (doSauMoi <= gioiHanDoSau && !Q.contains(v)) {
                    v.father = u;
                    v.doSau = doSauMoi;
                    L.push(v);
                    Q.add(v);
                }
            }
        }

        return null;
    }

    public void inKetQua(TrangThaiDoThi ketQua) {
        if (ketQua == null) {
            System.out.println("Khong tim thay duong di trong gioi han do sau!");
            return;
        }

        Stack<TrangThaiDoThi> duongDi = new Stack<>();
        TrangThaiDoThi hienTai = ketQua;

        while (hienTai != null) {
            duongDi.push(hienTai);
            hienTai = hienTai.father;
        }

        System.out.println("Duong di tim duoc:");
        while (!duongDi.isEmpty()) {
            System.out.print(duongDi.pop());
            if (!duongDi.isEmpty()) {
                System.out.print(" -> ");
            }
        }
        System.out.println();
    }
}