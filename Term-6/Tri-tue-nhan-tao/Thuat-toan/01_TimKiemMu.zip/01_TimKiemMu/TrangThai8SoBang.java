import java.util.ArrayList;
import java.util.List;

public class TrangThai8SoBang implements TrangThaiTimKiem {
    private String banCo;
    private TrangThaiTimKiem cha;

    private static final String DICH = "1238_4765";

    public TrangThai8SoBang(String banCo) {
        this.banCo = banCo;
        this.cha = null;
    }

    @Override
    public List<TrangThaiTimKiem> sinhTrangThaiKe() {
        List<TrangThaiTimKiem> ketQua = new ArrayList<>();

        /*
         * Thu tu toan tu:
         * Up, Left, Right, Down
         */
        themNeuHopLe(ketQua, -3); // Up
        themNeuHopLe(ketQua, -1); // Left
        themNeuHopLe(ketQua, 1);  // Right
        themNeuHopLe(ketQua, 3);  // Down

        return ketQua;
    }

    private void themNeuHopLe(List<TrangThaiTimKiem> ketQua, int huong) {
        int viTriTrong = banCo.indexOf('_');
        int viTriMoi = viTriTrong + huong;

        if (!diChuyenHopLe(viTriTrong, viTriMoi, huong)) {
            return;
        }

        char[] arr = banCo.toCharArray();

        char temp = arr[viTriTrong];
        arr[viTriTrong] = arr[viTriMoi];
        arr[viTriMoi] = temp;

        ketQua.add(new TrangThai8SoBang(new String(arr)));
    }

    private boolean diChuyenHopLe(int viTriTrong, int viTriMoi, int huong) {
        if (viTriMoi < 0 || viTriMoi >= 9) {
            return false;
        }

        int cotCu = viTriTrong % 3;
        int cotMoi = viTriMoi % 3;

        if (huong == -1 && cotCu == 0) {
            return false;
        }

        if (huong == 1 && cotCu == 2) {
            return false;
        }

        return true;
    }

    @Override
    public boolean laTrangThaiDich() {
        return banCo.equals(DICH);
    }

    @Override
    public String maTrangThai() {
        return banCo;
    }

    @Override
    public void setCha(TrangThaiTimKiem cha) {
        this.cha = cha;
    }

    @Override
    public TrangThaiTimKiem getCha() {
        return cha;
    }

    public void inBanCo() {
        System.out.println(banCo.charAt(0) + " " + banCo.charAt(1) + " " + banCo.charAt(2));
        System.out.println(banCo.charAt(3) + " " + banCo.charAt(4) + " " + banCo.charAt(5));
        System.out.println(banCo.charAt(6) + " " + banCo.charAt(7) + " " + banCo.charAt(8));
    }
}