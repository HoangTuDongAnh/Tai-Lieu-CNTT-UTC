import java.util.Objects;

public class TrangThaiDoThi {
    private String ten;
    public TrangThaiDoThi father;
    public int doSau;

    public TrangThaiDoThi(String ten) {
        this.ten = ten;
        this.father = null;
        this.doSau = 0;
    }

    public String getTen() {
        return ten;
    }

    @Override
    public String toString() {
        return ten;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof TrangThaiDoThi)) return false;
        TrangThaiDoThi other = (TrangThaiDoThi) obj;
        return Objects.equals(this.ten, other.ten);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ten);
    }
}