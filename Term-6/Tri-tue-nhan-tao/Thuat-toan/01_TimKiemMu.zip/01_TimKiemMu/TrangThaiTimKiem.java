import java.util.List;

public interface TrangThaiTimKiem {
    List<TrangThaiTimKiem> sinhTrangThaiKe();

    boolean laTrangThaiDich();

    String maTrangThai();

    void setCha(TrangThaiTimKiem cha);

    TrangThaiTimKiem getCha();
}