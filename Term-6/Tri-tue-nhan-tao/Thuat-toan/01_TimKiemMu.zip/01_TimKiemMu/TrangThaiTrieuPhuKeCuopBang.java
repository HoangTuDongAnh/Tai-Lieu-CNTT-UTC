import java.util.ArrayList;
import java.util.List;

public class TrangThaiTrieuPhuKeCuopBang implements TrangThaiTimKiem {
    private int a;
    private int b;
    private int k;

    private TrangThaiTimKiem cha;

    public TrangThaiTrieuPhuKeCuopBang(int a, int b, int k) {
        this.a = a;
        this.b = b;
        this.k = k;
        this.cha = null;
    }

    @Override
    public List<TrangThaiTimKiem> sinhTrangThaiKe() {
        List<TrangThaiTimKiem> ketQua = new ArrayList<>();

        /*
         * Cac toan tu:
         * 1 ke cuop
         * 1 trieu phu
         * 1 trieu phu + 1 ke cuop
         * 2 ke cuop
         * 2 trieu phu
         */
        int[][] toanTu = {
                {0, 1},
                {1, 0},
                {1, 1},
                {0, 2},
                {2, 0}
        };

        for (int[] tt : toanTu) {
            TrangThaiTrieuPhuKeCuopBang moi = diChuyen(tt[0], tt[1]);

            if (moi.hopLe()) {
                ketQua.add(moi);
            }
        }

        return ketQua;
    }

    private TrangThaiTrieuPhuKeCuopBang diChuyen(int soTrieuPhu, int soKeCuop) {
        if (k == 1) {
            return new TrangThaiTrieuPhuKeCuopBang(
                    a - soTrieuPhu,
                    b - soKeCuop,
                    0
            );
        } else {
            return new TrangThaiTrieuPhuKeCuopBang(
                    a + soTrieuPhu,
                    b + soKeCuop,
                    1
            );
        }
    }

    private boolean hopLe() {
        if (a < 0 || a > 3 || b < 0 || b > 3) {
            return false;
        }

        int trieuPhuBoTrai = a;
        int keCuopBoTrai = b;

        int trieuPhuBoPhai = 3 - a;
        int keCuopBoPhai = 3 - b;

        if (trieuPhuBoTrai > 0 && keCuopBoTrai > trieuPhuBoTrai) {
            return false;
        }

        if (trieuPhuBoPhai > 0 && keCuopBoPhai > trieuPhuBoPhai) {
            return false;
        }

        return true;
    }

    @Override
    public boolean laTrangThaiDich() {
        return a == 0 && b == 0 && k == 0;
    }

    @Override
    public String maTrangThai() {
        return "(" + a + "," + b + "," + k + ")";
    }

    @Override
    public void setCha(TrangThaiTimKiem cha) {
        this.cha = cha;
    }

    @Override
    public TrangThaiTimKiem getCha() {
        return cha;
    }
}